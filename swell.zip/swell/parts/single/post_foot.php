<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="p-articleFoot">
	<div class="p-articleMetas -bottom">
		<?php SWELL_Theme::get_parts( 'parts/single/item/term_list' ); ?>
	</div>
</div>
